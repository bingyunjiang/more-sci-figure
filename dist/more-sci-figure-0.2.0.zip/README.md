# More Sci Figure

本地优先、证据可追溯的科研图表数据提取、人工复核、论文级重绘与交付验证工具。

当前版本：`0.2.0`

> 核心原则：算法检测到的只是候选值。只有经过哈希绑定的人工复核，候选值才能进入正式 `data.csv`。

| 关键词 | 链接 |
| --- | --- |
| 功能总览 | [功能亮点](#功能亮点) |
| 快速使用 | [快速开始](#快速开始) |
| 完整流程 | [标准工作流](#标准工作流) |
| 命令行 | [CLI 命令](#cli-命令) |
| 输入与输出 | [输入与交付物](#输入与交付物) |
| 项目配置 | [项目规格与质量门](#项目规格与质量门) |
| 科研可信度 | [证据边界与拒绝条件](#证据边界与拒绝条件) |
| 测试 | [开发与验收](#开发与验收) |
| 版本计划 | [版本路线](#版本路线) |
| 变更记录 | [CHANGELOG.md](CHANGELOG.md) |

## 功能亮点

### 1. 来源不可静默替换

检查阶段记录原始文件 SHA-256、尺寸、PDF 页码、DPI 和测量栅格哈希。后续运行发现来源变化时会拒绝提取。

### 2. 候选值与正式值分离

```text
原图 → candidates.csv → 人工复核 → data.csv → 重绘
```

算法结果先写入 `candidates.csv`。复核决定必须覆盖全部候选编号并绑定候选文件 SHA-256；只有明确接受的记录会进入 `data.csv`。

### 3. 本地人工复核页

`extract` 自动生成 `review.html`。页面同时展示原尺寸证据叠图和逐候选决策表，可导出 `review-decisions.json`，整个过程不需要外部服务器。

### 4. 数据辅助质量判断

工具提供：

- 坐标标定斜率、截距、逐锚点残差和归一化 RMSE；
- 曲线覆盖率、最大连续缺口和分段信息；
- 散点面积、宽高、填充率和长宽比；
- 柱图矩形度、基线距离和组件统计；
- 像素量化与可评估标定残差形成的局部不确定度；
- 全图及绘图区残差和残差热图。

这些指标用于辅助复核，不替代科学判断。

### 5. 缺口和坐标尺度保持一致

曲线重绘遵守 `segment_break`，不会跨过缺失区域连线。`linear` 与 `log10` 坐标变换会同时用于标定和重绘。

### 6. 多格式与矢量导出

- 图源：PNG、JPEG、TIFF、BMP、WebP、PDF；
- 外部数据：CSV、TSV、JSON、XLSX、XLSM；
- 重绘输出：PNG、SVG、PDF。

旧版二进制 `.xls` 当前不支持，避免“检查时声称支持、重绘时失败”的不一致。

## 安装

推荐 Python 3.11 或更新版本。

```bash
python3 -m pip install -r requirements.txt
python3 scripts/more_sci_figure.py --help
```

作为 Codex 或其他 Agent skill 使用时，把本目录放入对应的 skills 目录，并要求 Agent 在执行前完整阅读 `SKILL.md`。

## 快速开始

### 第一步：检查并锁定来源

```bash
python3 scripts/more_sci_figure.py inspect \
  --input figure.png \
  --chart-type line \
  --out-dir evidence
```

打开 `evidence/project.json`，确认绘图区、坐标尺度、锚点、系列颜色和质量门。

### 第二步：提取候选值

```bash
python3 scripts/more_sci_figure.py extract \
  --spec evidence/project.json \
  --out-dir evidence
```

此时会生成 `candidates.csv` 和 `review.html`，但不会生成正式 `data.csv`。

### 第三步：人工复核

打开 `evidence/review.html`，完成决策并导出 `review-decisions.json`：

```bash
python3 scripts/more_sci_figure.py review-apply \
  --project-dir evidence \
  --decisions review-decisions.json
```

### 第四步：重绘并验证

```bash
python3 scripts/more_sci_figure.py render \
  --spec evidence/project.json \
  --data evidence/data.csv \
  --out-dir evidence/render

python3 scripts/more_sci_figure.py validate \
  --project-dir evidence \
  --reference figure.png
```

## 标准工作流

```mermaid
flowchart LR
    A["原始图片或 PDF"] --> B["inspect<br/>锁定来源"]
    B --> C["人工确认 project.json"]
    C --> D["extract<br/>生成候选值与质量指标"]
    D --> E["review.html<br/>人工逐项复核"]
    E --> F["review-apply<br/>生成正式 data.csv"]
    F --> G["render<br/>PNG / SVG / PDF"]
    G --> H["validate<br/>哈希、状态、残差"]
```

`pipeline` 第一次运行会停在人工复核门：

```bash
python3 scripts/more_sci_figure.py pipeline \
  --spec evidence/project.json \
  --out-dir evidence
```

完成人工复核后继续：

```bash
python3 scripts/more_sci_figure.py pipeline \
  --spec evidence/project.json \
  --out-dir evidence \
  --review-decisions review-decisions.json
```

## CLI 命令

| 命令 | 关键词 | 功能 |
| --- | --- | --- |
| `inspect` | 来源、哈希、PDF 页面 | 检查输入并生成项目模板 |
| `extract` | 标定、候选值、证据叠图 | 提取可见候选值并生成复核页 |
| `review` | 本地页面、逐项决策 | 重新生成 `review.html` |
| `review-apply` | 哈希绑定、正式数据 | 应用复核决定并生成 `data.csv` |
| `render` | 重绘、矢量、中文字体 | 导出 PNG、SVG 和 PDF |
| `validate` | 完整性、状态、残差 | 验证交付物和可选参考图 |
| `pipeline` | 门控管线 | 按顺序执行并在复核点暂停 |

查看详细参数：

```bash
python3 scripts/more_sci_figure.py COMMAND --help
```

## 输入与交付物

### 图像提取项目

```text
evidence/
├── project.json
├── source-report.json
├── candidates.csv
├── overlay.png
├── extraction-report.json
├── review.html
├── review-template.json
├── review-decisions.json
├── data.csv
├── manifest.json
├── validation-report.json
└── render/
    ├── render.png
    ├── render.svg
    ├── render.pdf
    └── render-report.json
```

### 直接数据重绘

外部数据直接重绘时：

- `extraction_status=not_applicable`；
- `review_status=not_applicable`；
- 原始数据保持不变；
- 项目目录内生成规范化 `data.csv`；
- 清单同时记录外部数据和规范化数据的哈希。

## 项目规格与质量门

从 [assets/project-template.json](assets/project-template.json) 开始。正式 Schema：

- [schemas/project.schema.json](schemas/project.schema.json)
- [schemas/review-decisions.schema.json](schemas/review-decisions.schema.json)

质量门示例：

```json
{
  "quality_gates": {
    "calibration": {
      "max_normalized_rmse": null,
      "require_three_anchors": false
    },
    "line": {
      "min_coverage": 0.5,
      "max_gap_fraction": null
    },
    "scatter": {
      "min_accepted_components": 1,
      "max_rejected_ratio": null
    }
  }
}
```

`null` 表示不设置该自动阈值。阈值应由图像分辨率、用途和研究要求决定，不能把示例值当作跨项目通用标准。

## 证据边界与拒绝条件

工具不会推断：

- 被遮挡或隐藏的数据点；
- 原始重复实验；
- 误差条统计含义；
- 作者拟合模型或显著性；
- 图中没有声明的单位和样本量。

以下情况不生成正式数值：

- 图表类型、绘图区或坐标变换未确认；
- 任一数值轴少于两个有效锚点；
- 来源或测量栅格哈希不匹配；
- 图例、文字和数据标记无法分离；
- 标记粘连、遮挡或存在无法解决的歧义；
- 人工复核缺失、候选哈希不一致或全部拒绝。

## 开发与验收

运行单元和回归测试：

```bash
python3 -m unittest discover \
  -s scripts/tests \
  -p "test_*.py" \
  -v
```

运行完整发布验收：

```bash
python3 scripts/release_acceptance.py
```

真实图表基准框架见 [benchmarks/README.md](benchmarks/README.md)。合成夹具只能用于回归测试，不能冒充真实世界基准。

## 版本路线

### v0.1.1 修正项，已并入 v0.2.0

- 保留曲线缺口；
- 应用声明的坐标尺度；
- 支持纯数据重绘的 `not_applicable` 状态；
- 统一数据格式支持范围；
- 扩充拒绝条件测试。

### v0.2.0 当前版本

- `candidates.csv → review → data.csv`；
- 候选哈希绑定的人工复核；
- 本地中文复核页面；
- 项目级质量门；
- 不确定度辅助字段；
- Lab 颜色距离与形状诊断；
- 中文 README、协议、CLI 和 Schema 说明。

### v0.3.0 计划

- 建立带来源、授权和标注协议的真实图表基准集；
- 增加排除区域、图例区域和可审计 OCR 候选；
- 增加更丰富的逐系列残差和误检/漏检指标；
- 在真实基准证据充分后扩展更多图表类型。

## 贡献

新增提取器或检测规则时，必须同时提交：

1. 合成单元夹具；
2. 至少一个未参与调参的保留样例；
3. 原尺寸证据叠图；
4. 拒绝和歧义测试；
5. 对交付契约与状态模型的说明。

## 许可证

当前技能包尚未包含独立 `LICENSE` 文件。公开发布前应由维护者明确选择许可证；在此之前不要默认推断授权范围。
