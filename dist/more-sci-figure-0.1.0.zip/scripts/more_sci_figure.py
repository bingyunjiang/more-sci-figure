#!/usr/bin/env python3
"""Unified local CLI for more-sci-figure v0.1."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import sys
from collections import deque
from pathlib import Path
from typing import Any, Callable

import numpy as np
from PIL import Image, ImageDraw


SCHEMA = "more-sci-figure.project.v1"
MANIFEST_SCHEMA = "more-sci-figure.manifest.v1"
SUPPORTED_CHARTS = {"line", "scatter", "bar", "histogram"}
VERSION = "0.1.0"


class FigureError(RuntimeError):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def resolve_from(base_file: Path, value: str) -> Path:
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (base_file.parent / path).resolve()


def parse_hex_color(value: str) -> tuple[int, int, int]:
    text = value.strip().lstrip("#")
    if len(text) != 6:
        raise FigureError(f"Color must be #RRGGBB: {value}")
    try:
        return tuple(int(text[index : index + 2], 16) for index in (0, 2, 4))
    except ValueError as exc:
        raise FigureError(f"Invalid color: {value}") from exc


def source_metadata(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise FigureError(f"Source not found: {path}")
    suffix = path.suffix.lower()
    result: dict[str, Any] = {
        "path": str(path),
        "sha256": sha256_file(path),
        "bytes": path.stat().st_size,
        "suffix": suffix,
    }
    if suffix in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}:
        with Image.open(path) as image:
            result.update(
                {
                    "kind": "raster",
                    "width": image.width,
                    "height": image.height,
                    "mode": image.mode,
                }
            )
    elif suffix == ".pdf":
        try:
            import fitz
        except ImportError as exc:
            raise FigureError("PyMuPDF is required for PDF inspection") from exc
        with fitz.open(path) as document:
            result.update(
                {
                    "kind": "pdf",
                    "pages": document.page_count,
                    "page_sizes_points": [
                        [float(page.rect.width), float(page.rect.height)] for page in document
                    ],
                }
            )
    elif suffix in {".csv", ".tsv", ".json", ".xlsx", ".xls"}:
        result["kind"] = "data"
    else:
        result["kind"] = "unknown"
    return result


def render_pdf_page(path: Path, page_number: int, output: Path, dpi: int = 144) -> dict[str, Any]:
    try:
        import fitz
    except ImportError as exc:
        raise FigureError("PyMuPDF is required for PDF rendering") from exc
    with fitz.open(path) as document:
        if page_number < 1 or page_number > document.page_count:
            raise FigureError(f"PDF page must be between 1 and {document.page_count}")
        page = document[page_number - 1]
        scale = dpi / 72.0
        pixmap = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
        output.parent.mkdir(parents=True, exist_ok=True)
        pixmap.save(output)
    with Image.open(output) as image:
        return {
            "path": str(output),
            "sha256": sha256_file(output),
            "width": image.width,
            "height": image.height,
            "dpi": dpi,
            "page": page_number,
        }


def inspect_command(input_path: Path, chart_type: str | None, out_dir: Path, page: int) -> None:
    input_path = input_path.expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    metadata = source_metadata(input_path)
    report: dict[str, Any] = {
        "schema": "more-sci-figure.source-report.v1",
        "source": metadata,
        "chart_type_proposal": chart_type,
        "numeric_extraction_authorized": False,
        "required_next": ["verify_chart_type", "verify_plot_box", "verify_axis_anchors"],
    }
    measurement: dict[str, Any] | None = None
    if metadata["kind"] == "pdf":
        measurement = render_pdf_page(input_path, page, out_dir / "source-page.png")
        report["measurement_raster"] = measurement
    elif metadata["kind"] == "raster":
        measurement = {
            "path": str(input_path),
            "sha256": metadata["sha256"],
            "width": metadata["width"],
            "height": metadata["height"],
        }
        report["measurement_raster"] = measurement
    write_json(out_dir / "source-report.json", report)

    relative_source = os.path.relpath(input_path, out_dir.resolve())
    project = {
        "schema": SCHEMA,
        "project_id": input_path.stem,
        "source": {
            "path": relative_source,
            "sha256": metadata["sha256"],
            "page": page if metadata["kind"] == "pdf" else None,
            "measurement_raster": (
                os.path.relpath(out_dir / "source-page.png", out_dir)
                if metadata["kind"] == "pdf"
                else relative_source
            ),
            "measurement_sha256": measurement["sha256"] if measurement else None,
        },
        "chart": {
            "type": chart_type or "unknown",
            "plot_box": [0, 0, 0, 0],
            "x_axis": {
                "scale": "linear",
                "anchors": [{"pixel": 0, "value": 0}, {"pixel": 0, "value": 1}],
            },
            "y_axis": {
                "scale": "linear",
                "anchors": [{"pixel": 0, "value": 0}, {"pixel": 0, "value": 1}],
            },
            "series": [
                {
                    "id": "series-a",
                    "color": "#d62728",
                    "tolerance": 45,
                    "min_area": 4,
                    "max_area": 500,
                }
            ],
        },
        "render": {
            "plot_type": chart_type or "line",
            "x": "x",
            "y": "y",
            "group": "series",
            "x_label": "",
            "y_label": "",
            "title": "",
        },
    }
    write_json(out_dir / "project.json", project)
    print(json.dumps({"status": "pass", "report": str(out_dir / "source-report.json"), "spec": str(out_dir / "project.json")}))


def validate_spec(spec: dict[str, Any], spec_path: Path, *, extraction: bool = True) -> list[str]:
    errors: list[str] = []
    if spec.get("schema") != SCHEMA:
        errors.append(f"schema must be {SCHEMA}")
    source = spec.get("source")
    if not isinstance(source, dict) or not source.get("path"):
        errors.append("source.path is required")
    else:
        path = resolve_from(spec_path, str(source["path"]))
        if not path.is_file():
            errors.append(f"source file not found: {path}")
        elif source.get("sha256") != sha256_file(path):
            errors.append("source.sha256 does not match the current source")
    chart = spec.get("chart")
    if not isinstance(chart, dict):
        errors.append("chart object is required")
        return errors
    chart_type = chart.get("type")
    if extraction and chart_type not in SUPPORTED_CHARTS:
        errors.append(f"unsupported chart.type: {chart_type}")
    box = chart.get("plot_box")
    if extraction and (
        not isinstance(box, list)
        or len(box) != 4
        or not all(isinstance(value, (int, float)) for value in box)
        or box[2] <= box[0]
        or box[3] <= box[1]
    ):
        errors.append("chart.plot_box must be [left, top, right, bottom] with positive area")
    if extraction:
        for axis_name in ("x_axis", "y_axis"):
            axis = chart.get(axis_name)
            anchors = axis.get("anchors") if isinstance(axis, dict) else None
            if not isinstance(anchors, list) or len(anchors) < 2:
                errors.append(f"chart.{axis_name} needs at least two anchors")
                continue
            pixels = [anchor.get("pixel") for anchor in anchors if isinstance(anchor, dict)]
            values = [anchor.get("value") for anchor in anchors if isinstance(anchor, dict)]
            if len(set(pixels)) < 2:
                errors.append(f"chart.{axis_name} anchor pixels must differ")
            if any(not isinstance(value, (int, float)) for value in values):
                errors.append(f"chart.{axis_name} anchor values must be numeric")
            if axis.get("scale", "linear") == "log10" and any(value <= 0 for value in values if isinstance(value, (int, float))):
                errors.append(f"chart.{axis_name} log10 anchors must be positive")
        series = chart.get("series")
        if not isinstance(series, list) or not series:
            errors.append("chart.series must contain at least one series")
        else:
            for entry in series:
                try:
                    parse_hex_color(str(entry.get("color", "")))
                except FigureError as exc:
                    errors.append(str(exc))
    return errors


class AxisMap:
    def __init__(self, axis: dict[str, Any]):
        self.scale = axis.get("scale", "linear")
        if self.scale not in {"linear", "log10"}:
            raise FigureError(f"Unsupported axis scale: {self.scale}")
        anchors = axis["anchors"]
        pixels = np.asarray([float(item["pixel"]) for item in anchors], dtype=float)
        values = np.asarray([float(item["value"]) for item in anchors], dtype=float)
        transformed = np.log10(values) if self.scale == "log10" else values
        self.slope, self.intercept = np.polyfit(pixels, transformed, 1)
        predicted = self.slope * pixels + self.intercept
        self.rmse = float(np.sqrt(np.mean((predicted - transformed) ** 2)))

    def value(self, pixel: float) -> float:
        transformed = self.slope * float(pixel) + self.intercept
        return float(10**transformed if self.scale == "log10" else transformed)

    def pixel(self, value: float) -> float:
        transformed = math.log10(value) if self.scale == "log10" else value
        return float((transformed - self.intercept) / self.slope)

    def report(self) -> dict[str, Any]:
        return {
            "scale": self.scale,
            "slope": float(self.slope),
            "intercept": float(self.intercept),
            "rmse_transformed_units": self.rmse,
        }


def color_mask(array: np.ndarray, color: tuple[int, int, int], tolerance: float) -> np.ndarray:
    delta = array.astype(np.int32) - np.asarray(color, dtype=np.int32)
    return np.sqrt(np.sum(delta * delta, axis=2)) <= tolerance


def components(mask: np.ndarray) -> list[list[tuple[int, int]]]:
    height, width = mask.shape
    visited = np.zeros_like(mask, dtype=bool)
    found: list[list[tuple[int, int]]] = []
    for y in range(height):
        for x in range(width):
            if not mask[y, x] or visited[y, x]:
                continue
            queue = deque([(x, y)])
            visited[y, x] = True
            pixels: list[tuple[int, int]] = []
            while queue:
                px, py = queue.popleft()
                pixels.append((px, py))
                for ny in range(max(0, py - 1), min(height, py + 2)):
                    for nx in range(max(0, px - 1), min(width, px + 2)):
                        if mask[ny, nx] and not visited[ny, nx]:
                            visited[ny, nx] = True
                            queue.append((nx, ny))
            found.append(pixels)
    return found


def prepare_measurement_raster(spec: dict[str, Any], spec_path: Path, out_dir: Path) -> tuple[Image.Image, Path]:
    source = spec["source"]
    source_path = resolve_from(spec_path, source["path"])
    measurement_value = source.get("measurement_raster")
    if measurement_value:
        measurement_path = resolve_from(spec_path, str(measurement_value))
    elif source_path.suffix.lower() == ".pdf":
        measurement_path = out_dir / "source-page.png"
        render_pdf_page(source_path, int(source.get("page") or 1), measurement_path)
    else:
        measurement_path = source_path
    if not measurement_path.is_file():
        raise FigureError(f"Measurement raster not found: {measurement_path}")
    expected = source.get("measurement_sha256")
    if expected and sha256_file(measurement_path) != expected:
        raise FigureError("measurement raster hash does not match the project")
    return Image.open(measurement_path).convert("RGB"), measurement_path


def extract_line(
    array: np.ndarray,
    box: tuple[int, int, int, int],
    series: list[dict[str, Any]],
    x_map: AxisMap,
    y_map: AxisMap,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    left, top, right, bottom = box
    crop = array[top : bottom + 1, left : right + 1]
    rows: list[dict[str, Any]] = []
    diagnostics: dict[str, Any] = {"series": []}
    for entry in series:
        mask = color_mask(crop, parse_hex_color(entry["color"]), float(entry.get("tolerance", 45)))
        supported = 0
        previous_x: int | None = None
        for local_x in range(mask.shape[1]):
            local_ys = np.flatnonzero(mask[:, local_x])
            if local_ys.size == 0:
                previous_x = None
                continue
            pixel_x = left + local_x
            pixel_y = top + float(np.median(local_ys))
            rows.append(
                {
                    "series": entry["id"],
                    "x": x_map.value(pixel_x),
                    "y": y_map.value(pixel_y),
                    "pixel_x": pixel_x,
                    "pixel_y": pixel_y,
                    "segment_break": previous_x is None,
                    "status": "visible",
                }
            )
            supported += 1
            previous_x = pixel_x
        coverage = supported / max(1, mask.shape[1])
        diagnostics["series"].append(
            {"id": entry["id"], "supported_columns": supported, "coverage": coverage}
        )
    return rows, diagnostics


def extract_scatter(
    array: np.ndarray,
    box: tuple[int, int, int, int],
    series: list[dict[str, Any]],
    x_map: AxisMap,
    y_map: AxisMap,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    left, top, right, bottom = box
    crop = array[top : bottom + 1, left : right + 1]
    rows: list[dict[str, Any]] = []
    diagnostics: dict[str, Any] = {"series": []}
    for entry in series:
        mask = color_mask(crop, parse_hex_color(entry["color"]), float(entry.get("tolerance", 45)))
        min_area = int(entry.get("min_area", 4))
        max_area = int(entry.get("max_area", 500))
        accepted = 0
        rejected = 0
        for component in components(mask):
            area = len(component)
            if area < min_area or area > max_area:
                rejected += 1
                continue
            xs = np.asarray([point[0] for point in component], dtype=float)
            ys = np.asarray([point[1] for point in component], dtype=float)
            pixel_x = left + float(xs.mean())
            pixel_y = top + float(ys.mean())
            rows.append(
                {
                    "series": entry["id"],
                    "x": x_map.value(pixel_x),
                    "y": y_map.value(pixel_y),
                    "pixel_x": pixel_x,
                    "pixel_y": pixel_y,
                    "component_area": area,
                    "status": "visible_component",
                }
            )
            accepted += 1
        diagnostics["series"].append(
            {"id": entry["id"], "accepted_components": accepted, "rejected_components": rejected}
        )
    rows.sort(key=lambda row: (str(row["series"]), float(row["x"])))
    return rows, diagnostics


def extract_bars(
    array: np.ndarray,
    box: tuple[int, int, int, int],
    series: list[dict[str, Any]],
    x_map: AxisMap,
    y_map: AxisMap,
    chart: dict[str, Any],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    left, top, right, bottom = box
    crop = array[top : bottom + 1, left : right + 1]
    baseline = float(chart.get("baseline_pixel", y_map.pixel(0.0)))
    rows: list[dict[str, Any]] = []
    diagnostics: dict[str, Any] = {"baseline_pixel": baseline, "series": []}
    candidates: list[dict[str, Any]] = []
    for entry in series:
        mask = color_mask(crop, parse_hex_color(entry["color"]), float(entry.get("tolerance", 45)))
        min_area = int(entry.get("min_area", 20))
        max_area = int(entry.get("max_area", 1000000))
        accepted = 0
        rejected = 0
        for component in components(mask):
            if len(component) < min_area or len(component) > max_area:
                rejected += 1
                continue
            xs = [point[0] for point in component]
            ys = [point[1] for point in component]
            x0, x1 = left + min(xs), left + max(xs)
            y0, y1 = top + min(ys), top + max(ys)
            if x1 - x0 < 2 or y1 - y0 < 2:
                rejected += 1
                continue
            endpoint = y0 if abs(y0 - baseline) >= abs(y1 - baseline) else y1
            candidates.append(
                {
                    "series": entry["id"],
                    "pixel_left": x0,
                    "pixel_top": y0,
                    "pixel_right": x1,
                    "pixel_bottom": y1,
                    "pixel_center": (x0 + x1) / 2.0,
                    "value": y_map.value(endpoint),
                    "baseline_value": y_map.value(baseline),
                    "status": "visible_rectangle",
                }
            )
            accepted += 1
        diagnostics["series"].append(
            {"id": entry["id"], "accepted_components": accepted, "rejected_components": rejected}
        )
    candidates.sort(key=lambda row: float(row["pixel_center"]))
    centers: list[float] = []
    for candidate in candidates:
        center = float(candidate["pixel_center"])
        category = next((index for index, known in enumerate(centers) if abs(known - center) <= 3), None)
        if category is None:
            centers.append(center)
            category = len(centers) - 1
        candidate["category_index"] = category
        candidate["x_value"] = x_map.value(center)
        rows.append(candidate)
    return rows, diagnostics


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def draw_overlay(image: Image.Image, chart_type: str, rows: list[dict[str, Any]], output: Path) -> None:
    overlay = image.copy()
    draw = ImageDraw.Draw(overlay)
    if chart_type == "line":
        grouped: dict[str, list[tuple[float, float]]] = {}
        for row in rows:
            grouped.setdefault(str(row["series"]), []).append((float(row["pixel_x"]), float(row["pixel_y"])))
        for points in grouped.values():
            for point in points:
                draw.ellipse((point[0] - 1.5, point[1] - 1.5, point[0] + 1.5, point[1] + 1.5), outline="#ff00ff")
    elif chart_type == "scatter":
        for row in rows:
            x, y = float(row["pixel_x"]), float(row["pixel_y"])
            draw.ellipse((x - 5, y - 5, x + 5, y + 5), outline="#ff00ff", width=2)
    else:
        for row in rows:
            draw.rectangle(
                (
                    float(row["pixel_left"]),
                    float(row["pixel_top"]),
                    float(row["pixel_right"]),
                    float(row["pixel_bottom"]),
                ),
                outline="#ff00ff",
                width=2,
            )
    output.parent.mkdir(parents=True, exist_ok=True)
    overlay.save(output)


def load_manifest(root: Path) -> dict[str, Any]:
    path = root / "manifest.json"
    if path.exists():
        return read_json(path)
    return {
        "schema": MANIFEST_SCHEMA,
        "extraction_status": "not_run",
        "render_status": "not_run",
        "delivery_status": "not_run",
        "artifacts": {},
    }


def artifact_entry(path: Path) -> dict[str, Any]:
    return {"path": str(path), "sha256": sha256_file(path), "bytes": path.stat().st_size}


def extract_command(spec_path: Path, out_dir: Path) -> dict[str, Any]:
    spec_path = spec_path.expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    spec = read_json(spec_path)
    errors = validate_spec(spec, spec_path, extraction=True)
    if errors:
        report = {
            "schema": "more-sci-figure.extraction-report.v1",
            "status": "failed",
            "numeric_output_authorized": False,
            "errors": errors,
        }
        write_json(out_dir / "extraction-report.json", report)
        raise FigureError("; ".join(errors))

    image, measurement_path = prepare_measurement_raster(spec, spec_path, out_dir)
    array = np.asarray(image, dtype=np.uint8)
    box = tuple(int(round(value)) for value in spec["chart"]["plot_box"])
    left, top, right, bottom = box
    if left < 0 or top < 0 or right >= image.width or bottom >= image.height:
        raise FigureError("chart.plot_box is outside the measurement raster")
    x_map = AxisMap(spec["chart"]["x_axis"])
    y_map = AxisMap(spec["chart"]["y_axis"])
    chart_type = spec["chart"]["type"]
    extractors: dict[str, Callable[..., tuple[list[dict[str, Any]], dict[str, Any]]]] = {
        "line": extract_line,
        "scatter": extract_scatter,
    }
    if chart_type in extractors:
        rows, diagnostics = extractors[chart_type](
            array, box, spec["chart"]["series"], x_map, y_map
        )
    else:
        rows, diagnostics = extract_bars(
            array, box, spec["chart"]["series"], x_map, y_map, spec["chart"]
        )
    if chart_type == "line":
        coverages = [float(item["coverage"]) for item in diagnostics["series"]]
        status = "pass" if rows and min(coverages, default=0.0) >= 0.5 else ("partial" if rows else "failed")
    else:
        status = "pass" if rows else "failed"
    data_path = out_dir / "data.csv"
    overlay_path = out_dir / "overlay.png"
    write_csv(data_path, rows)
    draw_overlay(image, chart_type, rows, overlay_path)
    report = {
        "schema": "more-sci-figure.extraction-report.v1",
        "status": status,
        "numeric_output_authorized": status == "pass",
        "source": {
            "path": str(resolve_from(spec_path, spec["source"]["path"])),
            "sha256": spec["source"]["sha256"],
            "measurement_raster": str(measurement_path),
            "measurement_sha256": sha256_file(measurement_path),
            "width": image.width,
            "height": image.height,
        },
        "chart_type": chart_type,
        "plot_box": list(box),
        "calibration": {"x_axis": x_map.report(), "y_axis": y_map.report()},
        "rows": len(rows),
        "diagnostics": diagnostics,
        "limitations": "Visible color-supported marks only; no hidden or fused observations inferred.",
    }
    report_path = out_dir / "extraction-report.json"
    write_json(report_path, report)
    project_copy = out_dir / "project.json"
    if project_copy.resolve() != spec_path:
        write_json(project_copy, spec)
    manifest = load_manifest(out_dir)
    manifest.update(
        {
            "project_id": spec.get("project_id"),
            "project_spec": artifact_entry(project_copy if project_copy.exists() else spec_path),
            "source_sha256": spec["source"]["sha256"],
            "extraction_status": status,
        }
    )
    manifest["artifacts"].update(
        {
            "data": artifact_entry(data_path),
            "overlay": artifact_entry(overlay_path),
            "extraction_report": artifact_entry(report_path),
        }
    )
    write_json(out_dir / "manifest.json", manifest)
    return report


def read_tabular_rows(path: Path) -> list[dict[str, Any]]:
    suffix = path.suffix.lower()
    if suffix in {".csv", ".tsv"}:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            return list(csv.DictReader(handle, delimiter="\t" if suffix == ".tsv" else ","))
    if suffix == ".json":
        payload = read_json(path)
        rows = payload.get("rows") if isinstance(payload, dict) else payload
        if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
            raise FigureError("JSON data must be a list of objects or an object with a rows list")
        return rows
    if suffix in {".xlsx", ".xlsm"}:
        try:
            from openpyxl import load_workbook
        except ImportError as exc:
            raise FigureError("openpyxl is required for Excel rendering") from exc
        workbook = load_workbook(path, read_only=True, data_only=True)
        sheet = workbook.active
        values = list(sheet.iter_rows(values_only=True))
        workbook.close()
        if not values:
            return []
        headers = [str(value) for value in values[0]]
        return [dict(zip(headers, row, strict=False)) for row in values[1:]]
    raise FigureError(f"Unsupported data format: {suffix}")


def numeric(row: dict[str, Any], key: str) -> float:
    try:
        return float(row[key])
    except (KeyError, ValueError) as exc:
        raise FigureError(f"Column {key!r} must contain numeric values") from exc


def series_colors(spec: dict[str, Any]) -> dict[str, str]:
    return {str(item["id"]): str(item["color"]) for item in spec.get("chart", {}).get("series", [])}


def render_command(spec_path: Path, data_path: Path, out_dir: Path) -> dict[str, Any]:
    cache_root = Path(os.environ.get("TMPDIR", "/tmp")) / "more-sci-figure-mpl"
    cache_root.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("MPLCONFIGDIR", str(cache_root))
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    spec_path = spec_path.expanduser().resolve()
    data_path = data_path.expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    spec = read_json(spec_path)
    errors = validate_spec(spec, spec_path, extraction=False)
    if errors:
        raise FigureError("; ".join(errors))
    rows = read_tabular_rows(data_path)
    if not rows:
        raise FigureError("No data rows to render")
    render = spec.get("render", {})
    plot_type = render.get("plot_type") or spec.get("chart", {}).get("type")
    if plot_type not in SUPPORTED_CHARTS:
        raise FigureError(f"Unsupported render plot type: {plot_type}")
    x_key = str(render.get("x", "x" if plot_type in {"line", "scatter"} else "category_index"))
    y_key = str(render.get("y", "y" if plot_type in {"line", "scatter"} else "value"))
    group_key = render.get("group")
    groups: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        group = str(row.get(str(group_key), "series")) if group_key else "series"
        groups.setdefault(group, []).append(row)
    colors = series_colors(spec)
    fig, axis = plt.subplots(figsize=(7.2, 4.8), dpi=160, constrained_layout=True)
    fallback = ["#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9"]
    if plot_type in {"line", "scatter"}:
        for index, (group, group_rows) in enumerate(groups.items()):
            xs = [numeric(row, x_key) for row in group_rows]
            ys = [numeric(row, y_key) for row in group_rows]
            color = colors.get(group, fallback[index % len(fallback)])
            if plot_type == "line":
                axis.plot(xs, ys, color=color, linewidth=1.8, label=group)
            else:
                axis.scatter(xs, ys, color=color, s=24, label=group)
    else:
        category_values = sorted({numeric(row, x_key) for row in rows})
        group_count = len(groups)
        width = 0.8 / max(1, group_count)
        for index, (group, group_rows) in enumerate(groups.items()):
            mapping = {numeric(row, x_key): numeric(row, y_key) for row in group_rows}
            positions = np.asarray(category_values) - 0.4 + width / 2 + index * width
            heights = [mapping.get(category, np.nan) for category in category_values]
            axis.bar(
                positions,
                heights,
                width=width,
                color=colors.get(group, fallback[index % len(fallback)]),
                label=group,
            )
        axis.set_xticks(category_values)
    axis.set_xlabel(str(render.get("x_label", "")))
    axis.set_ylabel(str(render.get("y_label", "")))
    axis.set_title(str(render.get("title", "")))
    axis.spines["top"].set_visible(False)
    axis.spines["right"].set_visible(False)
    axis.grid(axis="y", color="#d9d9d9", linewidth=0.6, alpha=0.6)
    if len(groups) > 1 or (group_key and next(iter(groups)) != "series"):
        axis.legend(frameon=False)
    outputs: dict[str, dict[str, Any]] = {}
    for suffix in ("png", "svg", "pdf"):
        path = out_dir / f"render.{suffix}"
        fig.savefig(path, facecolor="white")
        outputs[suffix] = artifact_entry(path)
    plt.close(fig)
    report = {
        "schema": "more-sci-figure.render-report.v1",
        "status": "pass",
        "plot_type": plot_type,
        "rows": len(rows),
        "mapping": {"x": x_key, "y": y_key, "group": group_key},
        "outputs": outputs,
    }
    write_json(out_dir / "render-report.json", report)
    root = out_dir.parent if out_dir.name == "render" else out_dir
    manifest = load_manifest(root)
    manifest["render_status"] = "pass"
    manifest["artifacts"]["render_report"] = artifact_entry(out_dir / "render-report.json")
    for suffix, entry in outputs.items():
        manifest["artifacts"][f"render_{suffix}"] = entry
    write_json(root / "manifest.json", manifest)
    return report


def validate_command(project_dir: Path, reference: Path | None = None) -> dict[str, Any]:
    project_dir = project_dir.expanduser().resolve()
    manifest_path = project_dir / "manifest.json"
    errors: list[str] = []
    warnings: list[str] = []
    if not manifest_path.exists():
        raise FigureError(f"Manifest not found: {manifest_path}")
    manifest = read_json(manifest_path)
    required = {
        "data": project_dir / "data.csv",
        "overlay": project_dir / "overlay.png",
        "extraction_report": project_dir / "extraction-report.json",
        "render_png": project_dir / "render" / "render.png",
        "render_svg": project_dir / "render" / "render.svg",
        "render_pdf": project_dir / "render" / "render.pdf",
    }
    artifact_checks: dict[str, Any] = {}
    for name, path in required.items():
        exists = path.is_file()
        artifact_checks[name] = {"path": str(path), "exists": exists}
        if not exists:
            errors.append(f"missing artifact: {name}")
            continue
        recorded = manifest.get("artifacts", {}).get(name, {}).get("sha256")
        current = sha256_file(path)
        artifact_checks[name]["sha256"] = current
        if recorded and recorded != current:
            errors.append(f"artifact hash mismatch: {name}")
    visual: dict[str, Any] = {"status": "not_run"}
    if reference is not None:
        reference = reference.expanduser().resolve()
        render_path = required["render_png"]
        if reference.is_file() and render_path.is_file():
            with Image.open(reference).convert("RGB") as ref_image, Image.open(render_path).convert("RGB") as rendered:
                if ref_image.size != rendered.size:
                    visual = {
                        "status": "canvas_mismatch",
                        "reference_size": list(ref_image.size),
                        "render_size": list(rendered.size),
                    }
                    warnings.append("reference and render canvases differ; no resized comparison was performed")
                else:
                    ref_array = np.asarray(ref_image, dtype=np.float32)
                    render_array = np.asarray(rendered, dtype=np.float32)
                    mae = float(np.mean(np.abs(ref_array - render_array)) / 255.0)
                    visual = {"status": "measured", "normalized_mae": mae, "canvas": list(ref_image.size)}
        else:
            warnings.append("reference or render PNG is missing")
    extraction = manifest.get("extraction_status", "not_run")
    render_status = manifest.get("render_status", "not_run")
    if errors:
        delivery = "failed"
    elif extraction == "pass" and render_status == "pass":
        delivery = "pass"
    elif extraction == "partial" and render_status == "pass":
        delivery = "partial"
    else:
        delivery = "failed"
    report = {
        "schema": "more-sci-figure.validation-report.v1",
        "status": "pass" if not errors else "failed",
        "delivery_status": delivery,
        "artifact_checks": artifact_checks,
        "visual_comparison": visual,
        "errors": errors,
        "warnings": warnings,
    }
    report_path = project_dir / "validation-report.json"
    write_json(report_path, report)
    manifest["delivery_status"] = delivery
    manifest["artifacts"]["validation_report"] = artifact_entry(report_path)
    write_json(manifest_path, manifest)
    return report


def pipeline_command(spec_path: Path, out_dir: Path) -> dict[str, Any]:
    extraction = extract_command(spec_path, out_dir)
    rendering = render_command(out_dir / "project.json", out_dir / "data.csv", out_dir / "render")
    validation = validate_command(out_dir)
    return {"extraction": extraction["status"], "render": rendering["status"], "delivery": validation["delivery_status"]}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Auditable scientific figure extraction and rendering.")
    parser.add_argument("--version", action="version", version=f"%(prog)s {VERSION}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    inspect_parser = subparsers.add_parser("inspect", help="Inspect a source and scaffold a project.")
    inspect_parser.add_argument("--input", required=True, type=Path)
    inspect_parser.add_argument("--chart-type", choices=sorted(SUPPORTED_CHARTS))
    inspect_parser.add_argument("--page", type=int, default=1)
    inspect_parser.add_argument("--out-dir", required=True, type=Path)

    extract_parser = subparsers.add_parser("extract", help="Extract calibrated visible data.")
    extract_parser.add_argument("--spec", required=True, type=Path)
    extract_parser.add_argument("--out-dir", required=True, type=Path)

    render_parser = subparsers.add_parser("render", help="Render data to PNG, SVG, and PDF.")
    render_parser.add_argument("--spec", required=True, type=Path)
    render_parser.add_argument("--data", required=True, type=Path)
    render_parser.add_argument("--out-dir", required=True, type=Path)

    validate_parser = subparsers.add_parser("validate", help="Validate a project delivery.")
    validate_parser.add_argument("--project-dir", required=True, type=Path)
    validate_parser.add_argument("--reference", type=Path)

    pipeline_parser = subparsers.add_parser("pipeline", help="Extract, render, and validate.")
    pipeline_parser.add_argument("--spec", required=True, type=Path)
    pipeline_parser.add_argument("--out-dir", required=True, type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "inspect":
            inspect_command(args.input, args.chart_type, args.out_dir, args.page)
            return 0
        if args.command == "extract":
            result = extract_command(args.spec, args.out_dir)
        elif args.command == "render":
            result = render_command(args.spec, args.data, args.out_dir)
        elif args.command == "validate":
            result = validate_command(args.project_dir, args.reference)
        else:
            result = pipeline_command(args.spec, args.out_dir)
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    except FigureError as exc:
        print(json.dumps({"status": "failed", "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
