from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path

from PIL import Image, ImageDraw


SCRIPT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SCRIPT_DIR))

import more_sci_figure as msf


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class AxisMapTests(unittest.TestCase):
    def test_linear_map_supports_reversed_pixel_axis(self) -> None:
        mapping = msf.AxisMap(
            {
                "scale": "linear",
                "anchors": [{"pixel": 100, "value": 0}, {"pixel": 20, "value": 10}],
            }
        )
        self.assertAlmostEqual(5.0, mapping.value(60), places=6)
        self.assertAlmostEqual(60.0, mapping.pixel(5), places=6)

    def test_log_map_fits_in_transformed_space(self) -> None:
        mapping = msf.AxisMap(
            {
                "scale": "log10",
                "anchors": [{"pixel": 0, "value": 1}, {"pixel": 100, "value": 100}],
            }
        )
        self.assertAlmostEqual(10.0, mapping.value(50), places=6)


class WorkflowTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def make_line_project(self) -> Path:
        source = self.root / "line.png"
        image = Image.new("RGB", (220, 140), "white")
        draw = ImageDraw.Draw(image)
        draw.line((20, 110, 200, 30), fill="#d62728", width=3)
        image.save(source)
        spec = {
            "schema": msf.SCHEMA,
            "project_id": "line-fixture",
            "source": {
                "path": str(source),
                "sha256": digest(source),
                "page": None,
                "measurement_raster": str(source),
                "measurement_sha256": digest(source),
            },
            "chart": {
                "type": "line",
                "plot_box": [20, 20, 200, 110],
                "x_axis": {
                    "scale": "linear",
                    "anchors": [{"pixel": 20, "value": 0}, {"pixel": 200, "value": 10}],
                },
                "y_axis": {
                    "scale": "linear",
                    "anchors": [{"pixel": 110, "value": 0}, {"pixel": 30, "value": 8}],
                },
                "series": [{"id": "trend", "color": "#d62728", "tolerance": 15}],
            },
            "render": {
                "plot_type": "line",
                "x": "x",
                "y": "y",
                "group": "series",
                "x_label": "Time",
                "y_label": "Response",
                "title": "Synthetic",
            },
        }
        spec_path = self.root / "project.json"
        msf.write_json(spec_path, spec)
        return spec_path

    def test_line_pipeline_writes_independent_statuses_and_artifacts(self) -> None:
        spec_path = self.make_line_project()
        output = self.root / "evidence"
        result = msf.pipeline_command(spec_path, output)
        self.assertEqual("pass", result["extraction"])
        self.assertEqual("pass", result["render"])
        self.assertEqual("pass", result["delivery"])
        manifest = msf.read_json(output / "manifest.json")
        self.assertEqual("pass", manifest["extraction_status"])
        self.assertEqual("pass", manifest["render_status"])
        self.assertEqual("pass", manifest["delivery_status"])
        for relative in (
            "data.csv",
            "overlay.png",
            "extraction-report.json",
            "render/render.png",
            "render/render.svg",
            "render/render.pdf",
            "validation-report.json",
        ):
            self.assertTrue((output / relative).is_file(), relative)

    def test_source_hash_mismatch_fails_spec_validation(self) -> None:
        spec_path = self.make_line_project()
        spec = msf.read_json(spec_path)
        spec["source"]["sha256"] = "0" * 64
        msf.write_json(spec_path, spec)
        errors = msf.validate_spec(spec, spec_path)
        self.assertIn("source.sha256 does not match the current source", errors)

    def test_excel_rows_are_supported_for_rendering(self) -> None:
        from openpyxl import Workbook

        path = self.root / "data.xlsx"
        workbook = Workbook()
        sheet = workbook.active
        sheet.append(["series", "x", "y"])
        sheet.append(["a", 0, 1.5])
        sheet.append(["a", 1, 2.5])
        workbook.save(path)
        workbook.close()
        rows = msf.read_tabular_rows(path)
        self.assertEqual(2, len(rows))
        self.assertEqual(2.5, rows[1]["y"])

    def test_scatter_component_centres_are_recovered(self) -> None:
        image = Image.new("RGB", (120, 100), "white")
        draw = ImageDraw.Draw(image)
        for x, y in ((20, 80), (60, 50), (100, 20)):
            draw.ellipse((x - 3, y - 3, x + 3, y + 3), fill="#0072b2")
        array = __import__("numpy").asarray(image)
        x_map = msf.AxisMap(
            {"scale": "linear", "anchors": [{"pixel": 10, "value": 0}, {"pixel": 110, "value": 10}]}
        )
        y_map = msf.AxisMap(
            {"scale": "linear", "anchors": [{"pixel": 90, "value": 0}, {"pixel": 10, "value": 8}]}
        )
        rows, diagnostics = msf.extract_scatter(
            array,
            (10, 10, 110, 90),
            [{"id": "points", "color": "#0072b2", "tolerance": 10, "min_area": 10, "max_area": 100}],
            x_map,
            y_map,
        )
        self.assertEqual(3, len(rows))
        self.assertEqual(3, diagnostics["series"][0]["accepted_components"])

    def test_bar_rectangles_are_recovered(self) -> None:
        image = Image.new("RGB", (140, 110), "white")
        draw = ImageDraw.Draw(image)
        draw.rectangle((20, 70, 40, 100), fill="#009e73")
        draw.rectangle((60, 50, 80, 100), fill="#009e73")
        draw.rectangle((100, 30, 120, 100), fill="#009e73")
        array = __import__("numpy").asarray(image)
        x_map = msf.AxisMap(
            {"scale": "linear", "anchors": [{"pixel": 10, "value": 0}, {"pixel": 130, "value": 3}]}
        )
        y_map = msf.AxisMap(
            {"scale": "linear", "anchors": [{"pixel": 100, "value": 0}, {"pixel": 20, "value": 8}]}
        )
        rows, diagnostics = msf.extract_bars(
            array,
            (10, 20, 130, 100),
            [{"id": "bars", "color": "#009e73", "tolerance": 10, "min_area": 100}],
            x_map,
            y_map,
            {"baseline_pixel": 100},
        )
        self.assertEqual(3, len(rows))
        self.assertEqual([0, 1, 2], [row["category_index"] for row in rows])
        self.assertEqual(3, diagnostics["series"][0]["accepted_components"])


if __name__ == "__main__":
    unittest.main()
