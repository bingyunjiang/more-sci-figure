#!/usr/bin/env python3
"""Local release gate for more-sci-figure."""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def run(command: list[str]) -> dict[str, object]:
    completed = subprocess.run(
        command,
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    return {
        "command": command,
        "returncode": completed.returncode,
        "status": "pass" if completed.returncode == 0 else "failed",
        "stderr_tail": completed.stderr[-1000:],
    }


def main() -> int:
    required = [
        "SKILL.md",
        "VERSION",
        "agents/openai.yaml",
        "assets/project-template.json",
        "references/artifact-contract.md",
        "references/extraction-protocol.md",
        "references/rendering-protocol.md",
        "scripts/more_sci_figure.py",
    ]
    structure = {
        "status": "pass" if all((ROOT / path).is_file() for path in required) else "failed",
        "missing": [path for path in required if not (ROOT / path).is_file()],
    }
    tests = run(
        [
            sys.executable,
            "-m",
            "unittest",
            "discover",
            "-s",
            str(ROOT / "scripts" / "tests"),
            "-p",
            "test_*.py",
            "-q",
        ]
    )
    cli = run([sys.executable, str(ROOT / "scripts" / "more_sci_figure.py"), "--version"])
    with tempfile.TemporaryDirectory(prefix="more-sci-figure-acceptance-") as temp:
        output = Path(temp) / "inspect"
        fixture = Path(temp) / "fixture.png"
        from PIL import Image

        Image.new("RGB", (64, 48), "white").save(fixture)
        inspect = run(
            [
                sys.executable,
                str(ROOT / "scripts" / "more_sci_figure.py"),
                "inspect",
                "--input",
                str(fixture),
                "--chart-type",
                "line",
                "--out-dir",
                str(output),
            ]
        )
        inspect["artifacts_present"] = all(
            (output / name).is_file() for name in ("source-report.json", "project.json")
        )
        if not inspect["artifacts_present"]:
            inspect["status"] = "failed"
    checks = {"structure": structure, "tests": tests, "cli": cli, "inspect": inspect}
    status = "pass" if all(check["status"] == "pass" for check in checks.values()) else "failed"
    report = {
        "schema": "more-sci-figure.release-acceptance.v1",
        "version": (ROOT / "VERSION").read_text(encoding="utf-8").strip(),
        "status": status,
        "checks": checks,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if status == "pass" else 2


if __name__ == "__main__":
    raise SystemExit(main())
