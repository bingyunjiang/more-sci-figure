---
name: more-sci-figure
description: Create auditable scientific-figure workflows from raster images, PDF figures, CSV, or Excel data. Use when Codex needs to inspect a figure source, calibrate chart axes, extract visible line/scatter/bar data, redraw publication figures, export PNG/SVG/PDF, compare a recreation with a reference, or deliver CSV, overlays, manifests, and separate extraction/render/delivery validation statuses.
---

# More Sci Figure

Build one evidence chain from source figure to extracted data and verified redraw. Work locally unless the user explicitly authorizes a remote OCR or vision service.

## Core rules

1. Preserve the source file and record its SHA-256 before measurement.
2. Measure only the original raster or the declared PDF page; never measure a preview or resized screenshot.
3. Require a verified plot box and at least two anchors per numeric axis before numeric extraction.
4. Keep extracted observations, supplied source data, and rendered outputs separate.
5. Never infer hidden points, raw replicates, error semantics, or author model parameters.
6. Keep these statuses independent:
   - `extraction_status`: whether visible values have sufficient source evidence.
   - `render_status`: whether the declared data rendered successfully.
   - `delivery_status`: whether the required artifacts and checks are complete.
7. A successful redraw never upgrades uncertain extraction.

## Workflow

Use `scripts/more_sci_figure.py` as the unified entry point.

### Inspect

```bash
python scripts/more_sci_figure.py inspect \
  --input figure.png --chart-type line --out-dir evidence
```

Review `source-report.json` and complete the generated `project.json`. If chart grammar, plot box, axis transform, or anchors are uncertain, stop before extraction.

### Extract

Read [references/extraction-protocol.md](references/extraction-protocol.md), then run:

```bash
python scripts/more_sci_figure.py extract \
  --spec evidence/project.json --out-dir evidence
```

Version 0.1 implements calibrated color-distinct `line`, compact filled `scatter`, and vertical `bar`/`histogram` extraction. Treat touching or occluded marks as unresolved. Inspect `overlay.png` at original size before accepting values.

### Render

Read [references/rendering-protocol.md](references/rendering-protocol.md), then run:

```bash
python scripts/more_sci_figure.py render \
  --spec evidence/project.json --data evidence/data.csv --out-dir evidence/render
```

The renderer exports PNG, SVG, and PDF from the declared data. Do not add uncertainty, statistical tests, smoothing, or trend fits unless independently supplied and declared.

### Validate

```bash
python scripts/more_sci_figure.py validate \
  --project-dir evidence --reference figure.png
```

Validation checks source identity, artifact presence, manifest consistency, and same-canvas image residuals when a reference is supplied.

### Pipeline

Use `pipeline` only after the spec is complete:

```bash
python scripts/more_sci_figure.py pipeline \
  --spec evidence/project.json --out-dir evidence
```

## Project contract

Read [references/artifact-contract.md](references/artifact-contract.md) when authoring or modifying a project spec. Start from `assets/project-template.json`.

Required delivery artifacts:

- `data.csv`: accepted visible values only.
- `overlay.png`: source-resolution evidence overlay.
- `extraction-report.json`: calibration, coverage, exclusions, and status.
- `render/render.png`, `render.svg`, `render.pdf`: deterministic redraws.
- `manifest.json`: hashes and independent status fields.
- `validation-report.json`: final artifact and optional visual checks.

## Refusal conditions

Return diagnostics without numeric values when:

- chart type is unknown or unsupported;
- plot bounds or axis transforms are unverified;
- fewer than two valid anchors exist for either numeric axis;
- a log axis contains non-positive anchors;
- source hash or dimensions differ from the declared source;
- colors cannot separate plotted marks from legends, axes, or annotations;
- marks are fused, occluded, or ambiguous beyond the extractor’s stated scope.

Keep project-specific corrections outside the skill. Add a new extractor only with synthetic fixtures, held-out examples, overlays, and regression tests.
