# Rendering protocol

## Contents

1. Data mapping
2. Scientific integrity
3. Export and validation

## Data mapping

Declare plot type and column mappings in `render`. Supported v0.1 plot types are `line`, `scatter`, `bar`, and `histogram`.

Group series only by a declared column. Preserve row order for line plots unless an explicit sort field is provided.

## Scientific integrity

- Do not fabricate error bars, significance, fits, or sample sizes.
- Do not drop outliers without a declared rule.
- Preserve units and axis transforms.
- Use a fixed, color-blind-aware palette only when series colors are not declared.
- Keep text editable in SVG and PDF.

## Export and validation

Export PNG, SVG, and PDF from one figure object. Record file hashes and canvas dimensions. When comparing to a reference, require equal pixel dimensions; report `canvas_mismatch` instead of resizing either image.
