# Extraction protocol

## Contents

1. Source lock
2. Calibration
3. Supported routes
4. Evidence review

## Source lock

Verify source SHA-256, raster width, and height before every run. Use PDF rendering only to create a declared page raster; preserve the PDF hash and page number.

## Calibration

Use at least two independently verified ticks per numeric axis. Prefer more anchors when available and review calibration RMSE. Declare `linear` or `log10`; never guess the transform from visual spacing alone.

## Supported routes

### Line

Use for color-distinct continuous strokes. The extractor samples each source x-column inside the plot box and uses the median supported y-pixel. Missing columns remain gaps. Legends and same-color annotations inside the plot box require a tighter plot box or a separate crop.

### Scatter

Use for compact filled markers with separable connected components. Reject touching, hollow, bubble-sized, or occluded markers. Component area bounds must be specified or reviewed.

### Bar and histogram

Use for vertical, solid-color rectangles with a declared or inferable zero baseline. Each connected component must correspond to one visible bar. Reject gradients, 3D effects, unresolved stacked segments, or legend swatches inside the plot box.

## Evidence review

Open `overlay.png` at original size.

- Line: confirm every trace lies on the visible stroke and gaps remain gaps.
- Scatter: confirm each ring centers one visible marker.
- Bar: confirm every rectangle covers one plotted bar and not a legend or label.

Do not use expected counts or expected values to tune detection.
