# Artifact contract

## Contents

1. Project schema
2. Axis calibration
3. Artifact lineage
4. Status model

## Project schema

Use `more-sci-figure.project.v1`.

```json
{
  "schema": "more-sci-figure.project.v1",
  "project_id": "example",
  "source": {
    "path": "figure.png",
    "sha256": "",
    "page": null
  },
  "chart": {
    "type": "line",
    "plot_box": [60, 30, 760, 520],
    "x_axis": {
      "scale": "linear",
      "anchors": [
        {"pixel": 60, "value": 0},
        {"pixel": 760, "value": 100}
      ]
    },
    "y_axis": {
      "scale": "linear",
      "anchors": [
        {"pixel": 520, "value": 0},
        {"pixel": 30, "value": 1}
      ]
    },
    "series": [
      {"id": "series-a", "color": "#d62728", "tolerance": 45}
    ]
  },
  "render": {
    "plot_type": "line",
    "x": "x",
    "y": "y",
    "group": "series",
    "x_label": "X",
    "y_label": "Y",
    "title": ""
  }
}
```

Paths in a project file resolve relative to the project file’s directory.

## Axis calibration

Fit pixels to transformed values from all anchors by least squares.

- `linear`: fit the value directly.
- `log10`: fit `log10(value)` and invert after mapping.

Record calibration RMSE. Do not authorize extraction when an anchor is invalid or the transform is unsupported.

## Artifact lineage

Maintain this immutable direction:

```text
source hash → calibration → extracted pixel evidence → data.csv
            → declared data mapping → render outputs
            → artifact and visual validation
```

Official source data may validate `data.csv`, but must not overwrite it.

## Status model

- `pass`: required checks succeeded.
- `partial`: some visible values were recovered, with declared gaps.
- `failed`: the requested stage ran but did not meet its gates.
- `not_run`: the stage did not run.
- `not_applicable`: the stage is outside the request.

`delivery_status=pass` requires all user-requested stages and artifacts to pass. It does not mean that hidden or ambiguous source data were recovered.
